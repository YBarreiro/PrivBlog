<?php 

require_once('modelo/functions.php');

$sesion=new Sesion;

session_start();

Sesion::cerrarSesion();


 ?>