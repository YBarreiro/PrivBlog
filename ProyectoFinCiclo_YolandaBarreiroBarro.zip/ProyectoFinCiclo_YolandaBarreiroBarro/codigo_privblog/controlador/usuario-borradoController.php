<?php 

require ('modelo/functions.php');
$sesion=new Sesion;


session_start();

require('vista/usuario-borrado.view.php');
 ?>