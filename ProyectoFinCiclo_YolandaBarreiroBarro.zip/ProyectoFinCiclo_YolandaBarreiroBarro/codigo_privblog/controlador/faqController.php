<?php 

require('modelo/functions.php');

session_start();


require('vista/faq.view.php');
?>