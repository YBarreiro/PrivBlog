<?php 

require_once('Tool.php');
require_once('ValidacionClass.php');
require_once('PersonaClass.php');
require_once('SesionClass.php');
require_once('PaginacionClass.php');
require_once('BusquedaClass.php');
require_once('EntradaClass.php');
require_once('CategoriaClass.php');
require_once('Asoc_Categoria_EntradaClass.php');
require_once('Archivo_EntradasClass.php');
require_once('EstadisticaClass.php');



