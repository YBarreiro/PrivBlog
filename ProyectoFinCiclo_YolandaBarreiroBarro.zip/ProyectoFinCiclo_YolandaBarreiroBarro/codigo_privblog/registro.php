<?php 
require('controlador/registroController.php');
 ?>