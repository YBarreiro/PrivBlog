<?php 

require('vista/error_conexion.view.php');
 ?>