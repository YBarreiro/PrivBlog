<?php 
require('controlador/resultados-categoriaController.php');
 ?>