<?php 
require('controlador/resultados-archivo-entradasController.php');
 ?>