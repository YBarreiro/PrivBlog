<?php require('vista/header.php') ?>
<div class="content">

<div class="container">
	<div class="row">
		<div class="col">
			<p class="mt-4"><strong>Tu cuenta ha sido eliminada.</strong></p> 
			<p>Si quieres hacer una cuenta nueva, haz click aquí: <a href="registro.php">Regístrate</a>.</p>
		</div>
	</div>
</div>
</div>

<?php require ('vista/footer.php'); ?>