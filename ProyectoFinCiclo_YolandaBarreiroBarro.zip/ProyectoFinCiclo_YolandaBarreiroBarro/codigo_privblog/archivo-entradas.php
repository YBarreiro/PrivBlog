<?php 
require('controlador/archivo-entradasController.php');
 ?>