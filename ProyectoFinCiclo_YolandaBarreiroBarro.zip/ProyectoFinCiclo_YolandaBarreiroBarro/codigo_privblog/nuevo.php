<?php 
require('controlador/nuevoController.php');
 ?>