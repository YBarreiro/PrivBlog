<?php 
require('controlador/editor-categoriasController.php');
 ?>