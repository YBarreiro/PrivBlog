<?php 
require('controlador/borrar-entradas-categoriaController.php');
 ?>