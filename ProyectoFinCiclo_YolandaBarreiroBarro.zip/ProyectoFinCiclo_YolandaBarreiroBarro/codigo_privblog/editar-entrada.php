<?php 
require('controlador/editar-entradaController.php');
 ?>