<?php 
require('controlador/borrar-categoriaController.php');
 ?>