<?php 
require('controlador/administracionController.php');
 ?>