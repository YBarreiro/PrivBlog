<?php 
require('controlador/singleController.php');
 ?>