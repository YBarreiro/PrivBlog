<?php 
require('controlador/cambiar-passController.php');
 ?>