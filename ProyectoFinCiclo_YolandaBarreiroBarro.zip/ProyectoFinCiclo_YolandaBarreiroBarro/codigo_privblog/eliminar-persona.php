<?php 
require('controlador/eliminar-personaController.php');
 ?>