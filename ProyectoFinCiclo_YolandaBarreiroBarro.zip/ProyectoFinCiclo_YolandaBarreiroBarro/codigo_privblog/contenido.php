<?php 
require('controlador/contenidoController.php');
 ?>


