<?php 
require('controlador/faqController.php');
 ?>