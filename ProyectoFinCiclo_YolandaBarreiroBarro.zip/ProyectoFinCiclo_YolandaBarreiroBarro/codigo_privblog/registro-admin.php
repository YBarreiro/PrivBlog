<?php 
require('controlador/registro-adminController.php');
 ?>