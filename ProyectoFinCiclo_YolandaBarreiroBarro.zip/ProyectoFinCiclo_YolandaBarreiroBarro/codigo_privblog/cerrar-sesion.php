<?php 
require('controlador/cerrar-sesionController.php');
 ?>