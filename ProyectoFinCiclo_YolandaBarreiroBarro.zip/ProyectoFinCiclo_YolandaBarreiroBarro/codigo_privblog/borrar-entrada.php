<?php 
require('controlador/borrar-entradaController.php');
 ?>