<?php 
require('controlador/busquedaController.php');
 ?>