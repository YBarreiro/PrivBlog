<?php 
require('controlador/borrar-asoc-categoriaController.php');
 ?>