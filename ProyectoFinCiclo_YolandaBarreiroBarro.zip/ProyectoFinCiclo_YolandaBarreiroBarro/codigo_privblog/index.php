<?php 

require('controlador/indexController.php');

 ?>