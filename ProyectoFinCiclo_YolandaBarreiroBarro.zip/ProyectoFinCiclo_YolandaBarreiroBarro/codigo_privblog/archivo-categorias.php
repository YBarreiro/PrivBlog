<?php 
require('controlador/archivo-categoriasController.php');
 ?>